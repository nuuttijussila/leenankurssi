var express = require('express');  
var router = express.Router();  

var Task = require('../models/Task');  
var task_controller = require('../controllers/taskController'); 

function isAuthenticated(req, res, next) { 
  if (req.session.user) 
      return next(); 
  res.redirect('/signin'); 
} 

router.get('/',isAuthenticated, task_controller.task_list);     

module.exports = router; 