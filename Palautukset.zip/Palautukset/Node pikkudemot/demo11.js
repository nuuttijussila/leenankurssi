var fs = require('fs');

fs.rename('mynewfile1.txt', 'myrenamedfile.txt', function (err) {
	if (err) throw err;
	console.log('Tiedosto on nimetty uudestaan!');
});